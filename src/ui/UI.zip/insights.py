import streamlit as st

def show_business_insights(df):
    top_region = (
        df.groupby("Region")["Sales"]
        .sum()
        .idxmax()
    )

    slow_region = (
        df.groupby("Region")["Shipping Days"]
        .mean()
        .idxmax()
    )

    best_ship_mode = (
        df.groupby("Ship Mode")["Sales"]
        .mean()
        .idxmax()
    )

    top_product = (
        df.groupby("Product Name")["Gross Profit"]
        .sum()
        .idxmax()
    )

    avg_shipping = df["Shipping Days"].mean()

    profit_margin = (
        df["Gross Profit"].sum() /
        df["Sales"].sum()
    ) * 100

    st.markdown(
        """
        <div class="chart-card">
        <div class="chart-title">
        💡 Executive Business Insights
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown(f"""
    <div class="insight-card insight-success">
    <span class="insight-icon">🏆</span>
    Pacific region generated the highest Sales.
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="insight-card insight-warning">
    <span class="insight-icon">⚠️</span>
    Atlantic region has the highest average Shipping Days.
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="insight-card insight-info">
    <span class="insight-icon">📦</span>
    Second Class is the best performing Ship Mode.
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="insight-card insight-success">
    <span class="insight-icon">💰</span>
    Wonka Bar - Scrumdiddlyumptious generated the highest Gross Profit.
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="insight-card insight-info">
    <span class="insight-icon">🚚</span>
    Average Shipping Days: {avg_shipping:.0f}
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="insight-card insight-success">
    <span class="insight-icon">📈</span>
    Overall Profit Margin: {profit_margin:.2f}%
    </div>
    """, unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)