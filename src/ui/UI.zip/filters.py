import streamlit as st


def sidebar_filters(df):
    """
    Creates sidebar filters and returns filtered dataframe.
    """

    st.sidebar.markdown("---")
    st.sidebar.subheader("🔍 Filters")

    # Region
    region = st.sidebar.multiselect(
        "Region",
        options=sorted(df["Region"].unique()),
        default=sorted(df["Region"].unique())
    )

    filtered = df[df["Region"].isin(region)]

    # Ship Mode
    ship_mode = st.sidebar.multiselect(
        "Ship Mode",
        options=sorted(filtered["Ship Mode"].unique()),
        default=sorted(filtered["Ship Mode"].unique())
    )

    filtered = filtered[
        filtered["Ship Mode"].isin(ship_mode)
    ]

    # State
    state = st.sidebar.multiselect(
        "State",
        options=sorted(filtered["State/Province"].unique()),
        default=sorted(filtered["State/Province"].unique())
    )

    filtered = filtered[
        filtered["State/Province"].isin(state)
    ]

    # Division
    division = st.sidebar.multiselect(
        "Division",
        options=sorted(filtered["Division"].unique()),
        default=sorted(filtered["Division"].unique())
    )

    filtered = filtered[
        filtered["Division"].isin(division)
    ]

    return filtered