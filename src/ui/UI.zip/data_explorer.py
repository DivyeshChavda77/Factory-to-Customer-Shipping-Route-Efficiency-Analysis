import streamlit as st
import pandas as pd

def data_explorer(df):
    # st.success("Data Explorer Loaded")
    st.markdown(
        '<h2 class="section-title">📄 Data Explorer</h2>',
        unsafe_allow_html=True
    )

    st.markdown(
        "Search, filter and download the shipping dataset."
    )

    filtered = df.copy()

    # ======================
    # Metrics
    # ======================

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Rows", f"{len(filtered):,}")
    c2.metric("Columns", filtered.shape[1])
    c3.metric("Missing", int(filtered.isna().sum().sum()))

    memory = filtered.memory_usage(deep=True).sum()/1024**2
    c4.metric("Memory", f"{memory:.2f} MB")

    st.write("")

    # ======================
    # Search + Download
    # ======================

    left, right = st.columns([5,1])

    with left:
        search = st.text_input(
            "",
            placeholder="🔍 Search Product Name...",
            key="search_product"            
        )

    if search:
        filtered = filtered[
            filtered["Product Name"].str.contains(
                search,
                case=False,
                na=False
            )
        ]

    with right:
        st.write("")
        csv = filtered.to_csv(index=False)

        st.download_button(
            "📥 Download CSV",
            csv,
            "filtered_shipping_data.csv",
            "text/csv",
            use_container_width=True
        )

    st.write("")


    # ======================
    # Data Table
    # ======================

    # st.dataframe(
    #     filtered,
    #     use_container_width=True,
    #     height=600
    # )
    st.dataframe(
    filtered,
    use_container_width=True,
    hide_index=True
)

