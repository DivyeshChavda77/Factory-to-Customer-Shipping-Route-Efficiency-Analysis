import streamlit as st
from textwrap import dedent


def route_summary(df):
    
    total_factory = 5
    total_region = df["Region"].nunique()
    total_state = df["State/Province"].nunique()
    total_city = df["City"].nunique()
    total_orders = len(df)
    avg_shipping = df["Shipping Days"].mean()
    best_city = (
        df.groupby("City")["Shipping Days"]
        .mean()
        .idxmin()
    )
    slowest_city = (
        df.groupby("City")["Shipping Days"]
        .mean()
        .idxmax()
    )

    st.markdown(f"""
    <div class="route-summary">

    <h3 style="margin-bottom:20px;color: #111827; font-weight: 700">
    📊 Route Summary
    </h3>

    <div class="summary-grid">

    <div class="summary-item">
        <span class="summary-icon">🏭</span>
        <span class="summary-label">Factories</span>
        <span class="summary-value">{total_factory}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">🌎</span>
        <span class="summary-label">Regions</span>
        <span class="summary-value">{total_region}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">🗺️</span>
        <span class="summary-label">States</span>
        <span class="summary-value">{total_state}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">🏙️</span>
        <span class="summary-label">Cities</span>
        <span class="summary-value">{total_city}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">📦</span>
        <span class="summary-label">Orders</span>
        <span class="summary-value">{total_orders:,}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">🚚</span>
        <span class="summary-label">Avg Shipping</span>
        <span class="summary-value">{avg_shipping:.0f} Days</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">⚡</span>
        <span class="summary-label">Best City</span>
        <span class="summary-value">{best_city}</span>
    </div>

    <div class="summary-item">
        <span class="summary-icon">🐢</span>
        <span class="summary-label">Slowest City</span>
        <span class="summary-value">{slowest_city}</span>
    </div>

    </div>
    </div>
    """, unsafe_allow_html=True)
