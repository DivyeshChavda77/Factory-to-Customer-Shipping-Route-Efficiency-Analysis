import plotly.graph_objects as go
import pandas as pd
import plotly.express as px


def factory_map():
    factories = pd.read_csv("artifacts/factory_coordinates.csv")

    fig = px.scatter_map(
        factories,
        lat="Latitude",
        lon="Longitude",
        hover_name="Factory",
        zoom=3,
        height=550,
    )

    fig.update_traces(
        mode="markers+text",
        text=["🏭"] * len(factories),
        textfont=dict(
            size=22,
            color="#F8FAFC"
        ),
        textposition="middle center",
        marker=dict(
            size=12,
            color="#3B82F6",
            opacity=1
        )
    )

    fig.update_layout(
        map_style="carto-darkmatter",
        margin=dict(
            l=0,
            r=0,
            t=0,
            b=0
        )
    )

    return fig

